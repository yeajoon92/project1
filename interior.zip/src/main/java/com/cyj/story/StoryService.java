package com.cyj.story;

import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;

import org.springframework.stereotype.Service;
import org.springframework.web.servlet.ModelAndView;

import com.cyj.comment.CommentDAO;
import com.cyj.comment.CommentDTO;
import com.cyj.like.LikeDAO;
import com.cyj.like.LikeDTO;
import com.cyj.member.MemberDTO;
import com.cyj.util.Pager;

@Service
public class StoryService {
	
	@Inject
	private StoryDAO storyDAO;
	@Inject
	private LikeDAO LikeDAO;
	@Inject
	private CommentDAO commentDAO;
	
	//list
	public ModelAndView list(Pager pager, StoryDTO storyDTO, CommentDTO commentDTO) throws Exception {
		ModelAndView mv = new ModelAndView();
		
		//story 뿌리기
		pager.makeRow();
		int totalCount = storyDAO.totalCount(pager);
		pager.makePage(totalCount);
		mv.setViewName("story/storyList");
		List<StoryDTO> ar = storyDAO.list(pager);
		mv.addObject("list", ar);
		mv.addObject("pager", pager);
		
		//like 뿌리기
		int count = 0;
		List<Integer> likelist = new ArrayList<Integer>();
		for(StoryDTO storyDTO2 : ar) { //(StoryDTO타입들을 모아놓은) ar에서 StoryDTO를 하나씩 꺼낼 때 변수명을 storyDTO2라고 하자
			count = storyDAO.likeCount(storyDTO2);
			likelist.add(count);
			System.out.println(storyDTO2.getNum()+"번 story post를 "+count+"명이 좋아합니다");
		}
		mv.addObject("likelist", likelist);
		mv.addObject("count", count);
		
		//comment 뿌리기
		List<List<CommentDTO>> comlist = new ArrayList<List<CommentDTO>>();
		for(StoryDTO storyDTO2: ar) {
			List<CommentDTO> ar2 = commentDAO.list(pager, storyDTO2.getNum());
			
			comlist.add(ar2);
			System.out.println(storyDTO2.getNum()+"번 story post에 "+ar2.size()+"개의 comment가 있습니다"); //story 글 하나 당 몇개의 comment가 있는지 찍어보기
		}
		mv.addObject("comlist", comlist);
		//mv2.addObject("pager", pager);
		
		return mv;
	}
	
	//insert
	public ModelAndView insert(StoryDTO storyDTO) throws Exception {
		
		//1. sequence num 가져오기
		int num = storyDAO.getNum();
		//storyDTO.setWriter(memberDTO.getId());
		
		//2. Story Table에 insert
		storyDTO.setNum(num);
		int result = storyDAO.insert(storyDTO);
		
		//transaction 처리
		if(result<1) {
			throw new Exception();
		}
		
		//3. HDD에 File Save
		
		//4. Files Table에 insert
		
		//transaction
		
		ModelAndView mv = new ModelAndView();
		mv.setViewName("redirect:./storyList");
		System.out.println("service : "+mv.getViewName());
		return mv;
	}
	
	//update
	public ModelAndView update(StoryDTO storyDTO) throws Exception {
		ModelAndView mv = new ModelAndView();
		int result = storyDAO.update(storyDTO);
		
		if(result<1 ) {
			throw new Exception();
		}
		
		//HDD save
		
		mv.setViewName("redirect:./storyList");
		return mv;
	}
	
	//delete
	public ModelAndView delete(int num) throws Exception {
		ModelAndView mv = new ModelAndView();
		
		//1. story Delete
		int result = storyDAO.delete(num);
		if(result<1) {
			throw new Exception();
		}
		//2. HDD Delete 준비
		
		//3. Files table Delete
		
		//4. HDD Delete
		
		mv.setViewName("redirect:./storyList");
		return mv;
	}
	
}
