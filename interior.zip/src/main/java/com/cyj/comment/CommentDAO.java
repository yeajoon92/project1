package com.cyj.comment;

import java.util.HashMap;
import java.util.List;

import javax.inject.Inject;

import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Repository;

import com.cyj.util.Pager;

@Repository
public class CommentDAO {
	
	@Inject
	private SqlSession sqlSession;
	private static final String NAMESPACE="commentMapper.";
	
	//getNum
	public int getNum() throws Exception {
		return sqlSession.selectOne(NAMESPACE+"getNum");
	}
	
	//totalCount
	public int totalCount(Pager pager) throws Exception {
		return sqlSession.selectOne(NAMESPACE+"totalCount", pager);
	}
	
	//list
	public List<CommentDTO> list(Pager pager, int storyNum) throws Exception {
		HashMap<String, Object> map = new HashMap<String, Object>();
		map.put("pager", pager);
		map.put("storyNum", storyNum);
		return sqlSession.selectList(NAMESPACE+"list", map);
	}
	
	//insert
	public int insert(CommentDTO commentDTO) throws Exception {
		return sqlSession.insert(NAMESPACE+"insert", commentDTO);
	}
	
	//update
	public int update(CommentDTO commentDTO) throws Exception {
		return sqlSession.update(NAMESPACE+"update", commentDTO);
	}
	
	//delete
	public int delete(int num) throws Exception {
		return sqlSession.delete(NAMESPACE+"delete", num);
	}
	
}
