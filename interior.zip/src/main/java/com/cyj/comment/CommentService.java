package com.cyj.comment;

import java.util.List;

import javax.inject.Inject;

import org.springframework.stereotype.Service;
import org.springframework.web.servlet.ModelAndView;

import com.cyj.util.Pager;

@Service
public class CommentService {
	
	@Inject
	private CommentDAO commentDAO;
	
	//list
	/*public ModelAndView list(Pager pager, int storyNum, CommentDTO commentDTO) throws Exception {
		System.out.println("commentList");
		pager.makeRow();
		int totalCount = commentDAO.totalCount(pager);
		pager.makePage(totalCount);
		ModelAndView mv = new ModelAndView();
		mv.setViewName("comment/commentList");
		mv.addObject("comlist", commentDAO.list(pager, storyNum));
		mv.addObject("pager", pager);
		return mv;
	}*/
	
	//select
	/*public ModelAndView select(int num) throws Exception {
		ModelAndView mv = new ModelAndView();
		CommentDTO commentDTO = commentDAO.select(num);
		return mv;
	}*/
	
	//insert
	public ModelAndView insert(Pager pager, CommentDTO commentDTO) throws Exception {
		ModelAndView mv = new ModelAndView();
		
		//1. sequence num 가져오기
		int num = commentDAO.getNum();
		
		//2. Comments Table에 insert
		commentDTO.setNum(num);
		int result = commentDAO.insert(commentDTO);
		
		//transaction 처리
		if(result<1) {
			throw new Exception();
		}
		
		pager.makeRow();
		int totalCount = commentDAO.totalCount(pager);
		pager.makePage(totalCount);
		mv.setViewName("comment/commentList");
		mv.addObject("comlist", commentDAO.list(pager, commentDTO.getStoryNum()));
		mv.addObject("pager", pager);
		System.out.println("service : "+mv.getViewName());
		return mv;
	}
	
	//update
	public ModelAndView update (CommentDTO commentDTO) throws Exception {
		ModelAndView mv = new ModelAndView();
		int result = commentDAO.update(commentDTO);
		
		if(result<1) {
			throw new Exception();
		}
		
		mv.setViewName("redirect:../story/storyList");
		//mv.setViewName("common/result");
		//mv.addObject("result", "Update Success");
		return mv;
	}
	
	//delete
	public ModelAndView delete(Pager pager, CommentDTO commentDTO, int num) throws Exception {
		ModelAndView mv = new ModelAndView();
		
		int result = commentDAO.delete(num);
		if(result<1) {
			throw new Exception();
		}
		
		pager.makeRow();
		int totalCount = commentDAO.totalCount(pager);
		pager.makePage(totalCount);
		mv.setViewName("comment/commentList");
		mv.addObject("comlist", commentDAO.list(pager, commentDTO.getStoryNum()));
		mv.addObject("pager", pager);
		System.out.println("service : "+mv.getViewName());
		return mv;
	}
	
}
