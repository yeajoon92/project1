package com.cyj.home;

import javax.inject.Inject;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.cyj.member.MemberDTO;
import com.cyj.member.MemberService;

@Controller
@RequestMapping(value="/member/**")
public class MemberController {
	
	@Inject
	private MemberService memberService;
	
	//signup form
	@RequestMapping(value="signup", method=RequestMethod.GET)
	public void signup() throws Exception {
		
	}
	
	//idCheck
	@RequestMapping(value="idCheck")
	public String idCheck(String id, Model model) throws Exception {
		//MemberDTO memberDTO = memberService.idCheck(id);
		
		return "common/result";
	}
	
	//signup process
	@RequestMapping(value="signup", method=RequestMethod.POST)
	public String signup(MemberDTO memberDTO, RedirectAttributes rd) throws Exception {
		
		
		memberDTO.setGrade("user");
		int result = memberService.signup(memberDTO);
		String path = "redirect:../";
		if(result<1) {
			path="redirect:./signup";
			rd.addFlashAttribute("msg", "회원가입 실패");
		}
		
		return path;
	}
	
	//login form
	@RequestMapping(value="login", method=RequestMethod.GET)
	public void login() throws Exception {
		
	}
	
	//login process
	@RequestMapping(value="login", method=RequestMethod.POST)
	public String login(MemberDTO memberDTO, HttpSession session, RedirectAttributes rd, String storyloc) throws Exception {
		memberDTO = memberService.login(memberDTO);
		if(storyloc==null) {
			storyloc="";
		}
		String path = "";
		if(memberDTO != null) {
			session.setAttribute("memberDTO", memberDTO);
			path = "redirect:../"+storyloc;
		}else {
			path = "redirect:./login";
			rd.addFlashAttribute("msg", "로그인 실패");
		}
		
		return path;
	}
	
	//forgot form //필요x ?
	@RequestMapping(value="forgot", method=RequestMethod.GET)
	public void forgot() throws Exception {
		
	}
	
	//forgotId process
	@RequestMapping(value="forgotId", method=RequestMethod.POST)
	public ModelAndView forgotId(MemberDTO memberDTO) throws Exception {
		ModelAndView mv = memberService.forgotId(memberDTO);
		return mv;
	}
	
	//forgotPw process
	@RequestMapping(value="forgotPw", method=RequestMethod.POST)
	public ModelAndView forgotPw(MemberDTO memberDTO) throws Exception {
		ModelAndView mv = memberService.forgotPw(memberDTO);
		return mv;
	}
	
	/*//update form
	@RequestMapping(value="update", method=RequestMethod.GET)
	public void update() throws Exception {
		
	}*/
	
	//myPage
	@RequestMapping(value="myPage", method=RequestMethod.GET)
	public void myPage() throws Exception {
		
	}
	
	//update process
	@RequestMapping(value="update", method=RequestMethod.POST)
	public String update(MemberDTO memberDTO, HttpSession session, RedirectAttributes rd) throws Exception {
		MemberDTO sMemberDTO = (MemberDTO)session.getAttribute("memberDTO");
		memberDTO.setId(sMemberDTO.getId());
		int result = memberService.update(memberDTO);
		if(result>0) {
			session.setAttribute("memberDTO", memberDTO);
		}else {
			rd.addFlashAttribute("msg", "Update Fail");
		}
		return "redirect:./myPage";
	}
	
	//delete form
	@RequestMapping(value="delete", method=RequestMethod.GET)
	public void delete() {
		
	}
	
	//delete process
	@RequestMapping(value="delete", method=RequestMethod.POST)
	public String delete(HttpSession session, RedirectAttributes rd) throws Exception {
		MemberDTO memberDTO = (MemberDTO)session.getAttribute("memberDTO");
		int result = memberService.delete(memberDTO.getId());
		String msg = "회원 탈퇴에 실패하였습니다.";
		if(result>0) {
			msg = "회원 탈퇴가 정상적으로 처리되었습니다.";
			session.invalidate();
		}
		rd.addFlashAttribute("msg", msg);
		return "redirect:../";
	}
	
	//logout
	@RequestMapping(value="logout")
	public String logout (HttpSession session) throws Exception {
		session.invalidate();
		return "redirect:../";
	}
	
}
