package com.cyj.home;

import javax.inject.Inject;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.cyj.file.FileService;

@Controller
@RequestMapping(value="/file/**")
public class FileController {
	
	@Inject
	private FileService fileService;
	
}
