package com.cyj.home;

import javax.inject.Inject;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.cyj.info.InfoDTO;
import com.cyj.info.InfoService;
import com.cyj.util.Pager;

@Controller
@RequestMapping(value="/info/**")
public class InfoController {
	
	@Inject
	private InfoService infoService;
	
	//list(for admin)
	@RequestMapping(value="infoList")
	public ModelAndView list(Pager pager) throws Exception {
		ModelAndView mv = infoService.list(pager);
		return mv;
	}
	
	//select
	@RequestMapping(value="infoSelect")
	public ModelAndView select(int num) throws Exception {
		ModelAndView mv = infoService.select(num);
		return mv;
	}
	
	//infoMain
	@RequestMapping(value="infoMain", method=RequestMethod.POST)
	public ModelAndView infoMain(InfoDTO infoDTO) throws Exception {
		ModelAndView mv = infoService.infoMain(infoDTO);
		return mv;
	}
	
	//write form
	@RequestMapping(value="infoWrite", method=RequestMethod.GET)
	public String insert(Model model) throws Exception {
		return "info/infoWrite";
	}
	
	//write process
	@RequestMapping(value="infoWrite", method=RequestMethod.POST)
	public ModelAndView insert(InfoDTO infoDTO) throws Exception {
		ModelAndView mv = infoService.insert(infoDTO);
		return mv;
	}
	
	//update form
	@RequestMapping(value="infoUpdate", method=RequestMethod.GET)
	public ModelAndView update(int num) throws Exception {
		ModelAndView mv = infoService.select(num);
		mv.setViewName("info/infoUpdate");
		return mv;
	}
	
	//update process
	@RequestMapping(value="infoUpdate", method=RequestMethod.POST)
	public ModelAndView update(InfoDTO infoDTO) throws Exception {
		ModelAndView mv = infoService.update(infoDTO);
		return mv;
	}
	
	//delete
	@RequestMapping(value="infoDelete")
	public ModelAndView delete(int num) throws Exception {
		ModelAndView mv = infoService.delete(num);
		return mv;
	}
	
}
