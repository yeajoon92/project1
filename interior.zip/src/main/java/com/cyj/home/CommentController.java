package com.cyj.home;

import javax.inject.Inject;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.cyj.comment.CommentDTO;
import com.cyj.comment.CommentService;
import com.cyj.util.Pager;

@Controller
@RequestMapping(value="/comment/**")
public class CommentController {
	
	@Inject
	private CommentService commentService;
	
	//list
	/*@RequestMapping(value="commentList")
	public ModelAndView list(Pager pager, int storyNum, CommentDTO commentDTO) throws Exception {
		ModelAndView mv = commentService.list(pager, storyNum, commentDTO);
		return mv;
	}*/
	
	//selecet
	/*@RequestMapping(value="commentSelect")
	public ModelAndView select(int num) throws Exception {
		ModelAndView mv = commentService.select(num);
		return mv;
	}*/
	
	//write(process)
	@RequestMapping(value="commentWrite", method=RequestMethod.POST)
	public ModelAndView insert(Pager pager, CommentDTO commentDTO, int idx) throws Exception {
		ModelAndView mv = commentService.insert(pager, commentDTO);
		return mv;
	}
	
	//update(form)
	/*@RequestMapping(value="commentUpdate", method=RequestMethod.GET)
	public ModelAndView update(int num) throws Exception {
		ModelAndView mv = commentService.select(num);
		mv.setViewName("comment/commentUpdate");
		return mv;
	}*/
	
	//update(process)
	@RequestMapping(value="commentUpdate", method=RequestMethod.POST)
	public ModelAndView update(CommentDTO commentDTO) throws Exception {
		ModelAndView mv = commentService.update(commentDTO);
		return mv;
	}
	
	//delete
	@RequestMapping(value="commentDelete", method=RequestMethod.POST)
	public ModelAndView delete(Pager pager, CommentDTO commentDTO, int idx, int num) throws Exception {
		ModelAndView mv = commentService.delete(pager, commentDTO, num);
		return mv;
	}
	
}
