package com.cyj.info;

import java.util.List;

import javax.inject.Inject;

import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Repository;

import com.cyj.util.Pager;

@Repository
public class InfoDAO {
	
	@Inject
	private SqlSession sqlSession;
	private static final String NAMESPACE="infoMapper.";
	
	//getNum
	public int getNum() throws Exception {
		return sqlSession.selectOne(NAMESPACE+"getNum");
	}
	
	//totalCount
	public int totalCount(Pager pager) throws Exception {
		return sqlSession.selectOne(NAMESPACE+"totalCount", pager);
	}
	
	//list(for admin)
	public List<InfoDTO> list(Pager pager) throws Exception {
		return sqlSession.selectList(NAMESPACE+"list", pager);
	}
	
	//select
	public InfoDTO select(int num) throws Exception {
		return sqlSession.selectOne(NAMESPACE+"select", num);
	}
	
	//selectedMain
	public InfoDTO selectedMain() throws Exception {
		return sqlSession.selectOne(NAMESPACE+"selectedMain");
	}
	
	//infoMain
	public int infoMain(InfoDTO infoDTO) throws Exception {
		return sqlSession.update(NAMESPACE+"infoMain", infoDTO);
	}
	
	//infoOthers
	public int infoOthers(InfoDTO infoDTO) throws Exception {
		return sqlSession.update(NAMESPACE+"infoOthers", infoDTO);
	}
	
	//insert
	public int insert(InfoDTO infoDTO) throws Exception {
		return sqlSession.insert(NAMESPACE+"insert", infoDTO);
	}
	
	//update
	public int update(InfoDTO infoDTO) throws Exception {
		return sqlSession.update(NAMESPACE+"update", infoDTO);
	}
	
	//delete
	public int delete(int num) throws Exception {
		return sqlSession.delete(NAMESPACE+"delete", num);
	}
	
}
