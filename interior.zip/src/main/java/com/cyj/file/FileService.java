package com.cyj.file;

import javax.inject.Inject;

import org.springframework.stereotype.Service;

@Service
public class FileService {
	
	@Inject
	private FileDAO fileDAO;
	
}
