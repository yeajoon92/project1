package com.cyj.member;

import javax.inject.Inject;

import org.springframework.stereotype.Service;
import org.springframework.web.servlet.ModelAndView;

@Service
public class MemberService {
	
	@Inject
	private MemberDAO memberDAO;
	
	//signup
	public int signup(MemberDTO memberDTO) throws Exception {
		return memberDAO.signup(memberDTO);
	}
	
	//idCheck
	/*public MemberDTO idCheck(String id) throws Exception {
		return memberDAO.idCheck(id);
	}*/
	
	//login
	public MemberDTO login(MemberDTO memberDTO) throws Exception {
		return memberDAO.login(memberDTO);
	}
	
	//forgotId
	public ModelAndView forgotId(MemberDTO memberDTO) throws Exception {
		ModelAndView mv = new ModelAndView();
		memberDTO =  memberDAO.forgotId(memberDTO);
		mv.setViewName("member/forgot");
		mv.addObject("memberDTO", memberDTO);
		return mv;
	}
	
	//forgotPw
	public ModelAndView forgotPw(MemberDTO memberDTO) throws Exception {
		ModelAndView mv = new ModelAndView();
		memberDAO.forgotPw(memberDTO);
		return mv;
	}
	
	//update
	public int update(MemberDTO memberDTO) throws Exception {
		return memberDAO.update(memberDTO);
	}
	
	//delete
	public int delete(String id) throws Exception {
		return memberDAO.delete(id);
	}
	
	/*//myPage
	public MemberDTO myPage(MemberDTO memberDTO) throws Exception {
		return memberDAO.myPage(memberDTO);
	}
	
	//logout
	public int logout() throws Exception {
		return memberDAO.logout();
	}*/
	
}
