package com.cyj.interior;

import java.sql.Date;

public class InteriorDTO {
	
	private int num;
	private String title;
	private String writer;
	private String contents;
	private Date reg_date;
	private int hit;
	private int likes;
	private String type;
	private String space;
	private String style;
	private String owner;
	
	public int getNum() {
		return num;
	}
	public void setNum(int num) {
		this.num = num;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getWriter() {
		return writer;
	}
	public void setWriter(String writer) {
		this.writer = writer;
	}
	public String getContents() {
		return contents;
	}
	public void setContents(String contents) {
		this.contents = contents;
	}
	public Date getReg_date() {
		return reg_date;
	}
	public void setReg_date(Date reg_date) {
		this.reg_date = reg_date;
	}
	public int getHit() {
		return hit;
	}
	public void setHit(int hit) {
		this.hit = hit;
	}
	public int getLikes() {
		return likes;
	}
	public void setLikes(int likes) {
		this.likes = likes;
	}
	public String getType() {
		if(this.type==null) {
			type="all";
		}
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getSpace() {
		if(this.space==null) {
			space="all";
		}
		return space;
	}
	public void setSpace(String space) {
		this.space = space;
	}
	public String getStyle() {
		if(this.style==null) {
			style="all";
		}
		return style;
	}
	public void setStyle(String style) {
		this.style = style;
	}
	public String getOwner() {
		return owner;
	}
	public void setOwner(String owner) {
		this.owner = owner;
	}
	
	
}
