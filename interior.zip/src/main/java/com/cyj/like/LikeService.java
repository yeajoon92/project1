package com.cyj.like;

import javax.inject.Inject;

import org.springframework.stereotype.Service;
import org.springframework.web.servlet.ModelAndView;

@Service
public class LikeService {
	
	@Inject
	private LikeDAO likeDAO;
	
	//like
	public ModelAndView like(LikeDTO likeDTO) throws Exception {
		ModelAndView mv = new ModelAndView();
		
		//select (해당 story에 좋아요를 누른적이 있는지 memberId 조회)
		LikeDTO likeDTO2 = likeDAO.select(likeDTO);
		
		int result=0;
		if(likeDTO2==null) { //누른 적 없음 -> Likes Table에 추가
			result = likeDAO.insert(likeDTO);
			System.out.println("insert result:"+result);
		}else if(likeDTO2!=null) { //누른 적 있음 -> Likes Table에서 삭제
			result = likeDAO.delete(likeDTO);
			System.out.println("delete result:"+result);
		}
		
		//select (한 story 당 좋아요를 누른 memberId의 갯수)
		int count = likeDAO.count(likeDTO);
		System.out.println(count);
		
		//mv.setViewName("redirect:../story/storyList");
		mv.setViewName("story/like");
		mv.addObject("count", count);
		return mv;
	}

}
