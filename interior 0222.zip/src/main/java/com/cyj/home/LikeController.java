package com.cyj.home;

import javax.inject.Inject;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.cyj.like.LikeDTO;
import com.cyj.like.LikeService;

@Controller
@RequestMapping(value="/like/**")
public class LikeController {
	
	@Inject
	private LikeService likeService;
	
	//insert
	@RequestMapping(value="like1", method=RequestMethod.POST)
	public ModelAndView like(LikeDTO likeDTO) throws Exception {
		ModelAndView mv = likeService.like(likeDTO);
		return mv;
	}
	
}
