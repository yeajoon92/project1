package com.cyj.home;

import javax.inject.Inject;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.cyj.comment.CommentDTO;
import com.cyj.member.MemberDTO;
import com.cyj.story.StoryDTO;
import com.cyj.story.StoryService;
import com.cyj.util.Pager;

@Controller
@RequestMapping(value="/story/**")
public class StoryController {
	
	@Inject
	private StoryService storyService;
	
	//list
	@RequestMapping(value="storyList")
	public ModelAndView list(Pager pager, StoryDTO storyDTO, CommentDTO commentDTO) throws Exception {
		ModelAndView mv = storyService.list(pager, storyDTO, commentDTO);
		return mv;
	}
	
	//write(process)
	@RequestMapping(value="storyWrite", method=RequestMethod.POST)
	public ModelAndView insert(StoryDTO storyDTO) throws Exception {
		ModelAndView mv = storyService.insert(storyDTO);
		return mv;
	}
	
	//update(process)
	@RequestMapping(value="storyUpdate", method=RequestMethod.POST)
	public ModelAndView udpate(StoryDTO storyDTO) throws Exception {
		ModelAndView mv = storyService.update(storyDTO);
		return mv;
	}
	
	//delete
	@RequestMapping(value="storyDelete", method=RequestMethod.POST)
	public ModelAndView delete(int num) throws Exception {
		ModelAndView mv = storyService.delete(num);
		return mv;
	}
	
}
