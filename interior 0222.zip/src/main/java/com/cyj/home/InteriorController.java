package com.cyj.home;

import javax.inject.Inject;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.cyj.interior.InteriorDTO;
import com.cyj.interior.InteriorService;
import com.cyj.util.Pager;

@Controller
@RequestMapping(value="/interior/**")
public class InteriorController {
	
	@Inject
	private InteriorService interiorService;
	
	//list
	@RequestMapping(value="interiorList")
	public ModelAndView list(Pager pager,InteriorDTO interiorDTO) throws Exception {
		ModelAndView mv = interiorService.list(pager, interiorDTO);
		return mv;
	}
	
	//select
	@RequestMapping(value="interiorSelect")
	public ModelAndView select(int num) throws Exception {
		ModelAndView mv = interiorService.select(num);
		return mv;
	}
	
	//write(form)
	@RequestMapping(value="interiorWrite", method=RequestMethod.GET)
	public String insert(Model model) throws Exception {
		return "interior/interiorWrite";
	}
	
	//write(process)
	@RequestMapping(value="interiorWrite", method=RequestMethod.POST)
	public ModelAndView insert(InteriorDTO interiorDTO) throws Exception {
		
		/*String realPath = session.getServletContext().getRealPath("resources/upload");
		System.out.println(realPath);*/
		
		ModelAndView mv = interiorService.insert(interiorDTO);
		return mv;
	}
	
	//update(form)
	@RequestMapping(value="interiorUpdate", method=RequestMethod.GET)
	public ModelAndView update(int num) throws Exception {
		ModelAndView mv = interiorService.select(num);
		mv.setViewName("interior/interiorUpdate");
		return mv;
	}
	
	//update(process)
	@RequestMapping(value="interiorUpdate", method=RequestMethod.POST)
	public ModelAndView update(InteriorDTO interiorDTO) throws Exception {
		ModelAndView mv = interiorService.update(interiorDTO);
		return mv;
	}
	
	//delete
	@RequestMapping(value="interiorDelete", method=RequestMethod.POST)
	public ModelAndView delete(int num) throws Exception {
		ModelAndView mv = interiorService.delete(num);
		return mv;
	}
	
}
