package com.cyj.interior;

import java.util.HashMap;
import java.util.List;

import javax.inject.Inject;

import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Repository;

import com.cyj.util.Pager;

@Repository
public class InteriorDAO {
	
	@Inject
	private SqlSession sqlSession;
	private static final String NAMESPACE="interiorMapper.";
	
	//getNum
	public int getNum() throws Exception {
		return sqlSession.selectOne(NAMESPACE+"getNum");
	}
	
	//totalCount
	public int totalCount(Pager pager) throws Exception {
		return sqlSession.selectOne(NAMESPACE+"totalCount", pager);
	}
	
	//list
	public List<InteriorDTO> list(Pager pager, InteriorDTO interiorDTO) throws Exception {
		HashMap<String, Object> map = new HashMap<String, Object>();
		map.put("pager", pager);
		map.put("interiorDTO", interiorDTO); //interiorDTO를 list에서 넘겨주는 이유는 list 뿌릴 때 제목에 DTO들 띄울거기 때문
		return sqlSession.selectList(NAMESPACE+"list", map);
	}
	
	//select
	public InteriorDTO select(int num) throws Exception {
		return sqlSession.selectOne(NAMESPACE+"select", num);
	}
	
	//insert
	public int insert(InteriorDTO interiorDTO) throws Exception {
		return sqlSession.insert(NAMESPACE+"insert", interiorDTO);
	}
	
	//update
	public int update(InteriorDTO interiorDTO) throws Exception {
		return sqlSession.update(NAMESPACE+"update", interiorDTO);
	}
	
	//delete
	public int delete(int num) throws Exception {
		return sqlSession.delete(NAMESPACE+"delete", num);
	}
	
}
