package com.cyj.interior;

import javax.inject.Inject;

import org.springframework.stereotype.Service;
import org.springframework.web.servlet.ModelAndView;

import com.cyj.file.FileDAO;
import com.cyj.util.Pager;

@Service
public class InteriorService {
	
	@Inject
	private InteriorDAO interiorDAO;
	@Inject
	private FileDAO fileDAO;
	
	//list
	public ModelAndView list(Pager pager, InteriorDTO interiorDTO) throws Exception {
		pager.makeRow();
		int totalCount = interiorDAO.totalCount(pager);
		pager.makePage(totalCount);
		ModelAndView mv = new ModelAndView();
		mv.setViewName("interior/interiorList");
		mv.addObject("list", interiorDAO.list(pager, interiorDTO));
		mv.addObject("pager", pager);
		return mv;
	}
	
	//select
	public ModelAndView select(int num) throws Exception {
		ModelAndView mv = new ModelAndView();
		
		//1. Interior Table
		InteriorDTO interiorDTO = interiorDAO.select(num);
		
		//2. Files Table
		if(interiorDTO != null) {
			mv.setViewName("interior/interiorSelect");
			mv.addObject("interiorDTO", interiorDTO);
		}else {
			mv.setViewName("redirect:./interiorList");
			mv.addObject("msg", "글이 없습니다");
		}
		
		return mv;
	}
	
	//insert
	public ModelAndView insert(InteriorDTO interiorDTO) throws Exception {
		
		//1. sequence num 가져오기
		int num = interiorDAO.getNum();
		interiorDTO.setWriter("admin"); //null로 처리하려면 ("");
		
		//2. Interior Table에 insert
		interiorDTO.setNum(num);		
		int result = interiorDAO.insert(interiorDTO);
		
		//transaction 처리
		if(result<1) {
			throw new Exception();
		}
		
		//3. HDD에 File Save
		
		//4. Files Table insert
		
		//transaction
		
		ModelAndView mv = new ModelAndView();
		//mv.setViewName("redirect:./interiorList"); // message 안 띄우고 (request 소멸되고) 바로 list페이지로 가기
		mv.setViewName("common/message"); // setViewName! servlet 거쳐서 앞에 /WEB-INf/views/, 뒤에 .jsp 붙여옴
		mv.addObject("msg", "Write Success");
		mv.addObject("loc", "./interiorList");
		System.out.println("service : "+mv.getViewName());
		return mv;
	}
	
	//update
	public ModelAndView update(InteriorDTO interiorDTO) throws Exception {
		ModelAndView mv = new ModelAndView();
		int result = interiorDAO.update(interiorDTO);
		
		if(result<1) {
			throw new Exception();
		}
		
		//HDD save
		
		String msg = "Update Success";
		
		//mv.setViewName("redirect:./interiorSelect?num="+interiorDTO.getNum());
		mv.setViewName("common/message");
		mv.addObject("msg", msg);
		mv.addObject("loc", "./interiorSelect?num="+interiorDTO.getNum());
		return mv;
	}
	
	//delete
	public ModelAndView delete(int num) throws Exception {
		ModelAndView mv = new ModelAndView();
		
		//1. interior Delete
		int result = interiorDAO.delete(num);
		if(result<1) {
			throw new Exception();
		}
		//2. HDD Delete 준비
		
		//3. Files table Delete
		
		//4. HDD Delete
		
		
		//mv.setViewName("redirect:./interiorList");
		mv.setViewName("common/message");
		mv.addObject("msg", "Delete Success");
		mv.addObject("loc", "./interiorList");
		return mv;
	}
	
}
