package com.cyj.member;

import javax.inject.Inject;

import org.springframework.stereotype.Service;
import org.springframework.web.servlet.ModelAndView;

@Service
public class MemberService {
	
	@Inject
	private MemberDAO memberDAO;
	
	//signup
	public int signup(MemberDTO memberDTO) throws Exception {
		return memberDAO.signup(memberDTO);
	}
	
	//idCheck
	/*public MemberDTO idCheck(String id) throws Exception {
		return memberDAO.idCheck(id);
	}*/
	
	//login
	public MemberDTO login(MemberDTO memberDTO) throws Exception {
		return memberDAO.login(memberDTO);
	}
	
	//forgotId
	public ModelAndView forgotId(MemberDTO memberDTO) throws Exception {
		ModelAndView mv = new ModelAndView();
		System.out.println("s");

		MemberDTO memberDTO2 = memberDAO.forgotId(memberDTO);
		mv.setViewName("common/message");
		//mv.addObject("memberDTO", memberDTO2);
		mv.addObject("msg", "ID는"+memberDTO2.getId()+"입니다.");
		mv.addObject("loc", "../member/forgot");
		System.out.println(memberDAO.forgotId(memberDTO2));
		
		return mv;
	}
	
	//forgotPw
	public ModelAndView forgotPw(MemberDTO memberDTO) throws Exception {
		ModelAndView mv = new ModelAndView();
		memberDAO.forgotPw(memberDTO);
		return mv;
	}
	
	//update
	public int update(MemberDTO memberDTO) throws Exception {
		return memberDAO.update(memberDTO);
	}
	
	//delete
	public int delete(String id) throws Exception {
		return memberDAO.delete(id);
	}
	
	/*//myPage
	public MemberDTO myPage(MemberDTO memberDTO) throws Exception {
		return memberDAO.myPage(memberDTO);
	}
	
	//logout
	public int logout() throws Exception {
		return memberDAO.logout();
	}*/
	
}
