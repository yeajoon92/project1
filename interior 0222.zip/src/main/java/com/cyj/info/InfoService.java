package com.cyj.info;

import javax.inject.Inject;

import org.springframework.stereotype.Service;
import org.springframework.web.servlet.ModelAndView;

import com.cyj.util.Pager;

@Service
public class InfoService {
	
	@Inject
	private InfoDAO infoDAO;
	
	//list(for admin)
	public ModelAndView list(Pager pager) throws Exception {
		ModelAndView mv = new ModelAndView();
		
		pager.makeRow();
		int totalCount = infoDAO.totalCount(pager);
		pager.makePage(totalCount);
		
		InfoDTO infoDTO = infoDAO.selectedMain();
		
		mv.setViewName("info/infoList");
		mv.addObject("list", infoDAO.list(pager));
		mv.addObject("pager", pager);
		mv.addObject("infoDTO", infoDTO);
		return mv;
	}
	
	//select
	public ModelAndView select(int num) throws Exception {
		ModelAndView mv = new ModelAndView();
		InfoDTO infoDTO = infoDAO.select(num);
		mv.setViewName("info/infoSelect");
		mv.addObject("infoDTO", infoDTO);
		return mv;
	}
	
	//infoMain
	public ModelAndView infoMain(InfoDTO infoDTO) throws Exception {
		ModelAndView mv = new ModelAndView();
		
		int result = infoDAO.infoMain(infoDTO); //classify에 main
		int result2 = infoDAO.infoOthers(infoDTO); //나머지는 classify에 others
		
		String msg = "Info Main Success";
		mv.setViewName("common/message");
		mv.addObject("msg", msg);
		mv.addObject("loc", "./infoList");
		return mv;
	}
	
	//insert
	public ModelAndView insert(InfoDTO infoDTO) throws Exception {
		int num = infoDAO.getNum();
		infoDTO.setNum(num);
		infoDTO.setWriter("admin");
		int result = infoDAO.insert(infoDTO);
		if(result<1) {
			throw new Exception();
		}
		ModelAndView mv = new ModelAndView();
		mv.setViewName("common/message");
		mv.addObject("msg", "Info Write Success");
		mv.addObject("loc", "./infoList");
		System.out.println("service : "+mv.getViewName());
		return mv;
	}
	
	//update
	public ModelAndView update(InfoDTO infoDTO) throws Exception {
		ModelAndView mv = new ModelAndView();
		int result = infoDAO.update(infoDTO);
		if(result<1) {
			throw new Exception();
		}
		String msg = "Info Update Success";
		mv.setViewName("common/message");
		mv.addObject("msg", msg);
		mv.addObject("loc", "./infoSelect?num="+infoDTO.getNum());
		return mv;
	}
	
	//delete
	public ModelAndView delete(int num) throws Exception {
		ModelAndView mv = new ModelAndView();
		int result = infoDAO.delete(num);
		if(result<1) {
			throw new Exception();
		}
		mv.setViewName("common/message");
		mv.addObject("msg", "Info Delete Success");
		mv.addObject("loc", "./infoList");
		return mv;
	}
	
}
