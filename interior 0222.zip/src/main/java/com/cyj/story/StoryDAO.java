package com.cyj.story;

import java.util.HashMap;
import java.util.List;

import javax.inject.Inject;

import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Repository;

import com.cyj.comment.CommentDTO;
import com.cyj.member.MemberDTO;
import com.cyj.util.Pager;

import oracle.jdbc.internal.OracleStatement.SqlKind;

@Repository
public class StoryDAO {
	
	@Inject
	private SqlSession sqlSession;
	private static final String NAMESPACE="storyMapper.";
	
	//getNum
	public int getNum() throws Exception {
		return sqlSession.selectOne(NAMESPACE+"getNum");
	}
	
	//totalCount
	public int totalCount(Pager pager) throws Exception {
		return sqlSession.selectOne(NAMESPACE+"totalCount", pager);
	}
	
	//list
	public List<StoryDTO> list(Pager pager) throws Exception {
		return sqlSession.selectList(NAMESPACE+"list", pager);
	}
	
	//insert
	public int insert(StoryDTO storyDTO) throws Exception {
		return sqlSession.insert(NAMESPACE+"insert", storyDTO);
	}
	
	//update
	public int update(StoryDTO storyDTO) throws Exception {
		return sqlSession.update(NAMESPACE+"update", storyDTO);
	}
	
	//delete
	public int delete(int num) throws Exception {
		return sqlSession.delete(NAMESPACE+"delete", num);
	}
	
	//likeCount
	public int likeCount(StoryDTO storyDTO) throws Exception {
		return sqlSession.selectOne(NAMESPACE+"likeCount", storyDTO);
	}
	
}
