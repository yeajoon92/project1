package com.cyj.like;

import javax.inject.Inject;

import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Repository;

@Repository
public class LikeDAO {
	
	@Inject
	private SqlSession sqlSession;
	private static final String NAMESPACE="likeMapper.";
	
	//select
	public LikeDTO select(LikeDTO likeDTO) throws Exception {
		return sqlSession.selectOne(NAMESPACE+"select", likeDTO);
	}
	
	//insert
	public int insert(LikeDTO likeDTO) throws Exception {
		return sqlSession.insert(NAMESPACE+"like", likeDTO);
	}
	
	//delete
	public int delete(LikeDTO likeDTO) throws Exception {
		return sqlSession.delete(NAMESPACE+"delete", likeDTO);
	}
	
	//count
	public int count(LikeDTO likeDTO) throws Exception {
		return sqlSession.selectOne(NAMESPACE+"count", likeDTO);
	}

}
